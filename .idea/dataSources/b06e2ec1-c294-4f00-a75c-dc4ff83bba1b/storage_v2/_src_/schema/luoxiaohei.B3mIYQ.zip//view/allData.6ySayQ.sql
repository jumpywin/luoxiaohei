create view allData as
select `luoxiaohei`.`character`.`id`                             AS `id`,
       `luoxiaohei`.`character`.`name`                           AS `name`,
       group_concat(`luoxiaohei`.`ability`.`name` separator ',') AS `abilities`,
       group_concat(`luoxiaohei`.`ability`.`note` separator ',') AS `abilities_note`,
       `luoxiaohei`.`racial`.`name`                              AS `racial`,
       `luoxiaohei`.`character`.`note`                           AS `note`
from (((`luoxiaohei`.`character` left join `luoxiaohei`.`character-ability` on ((`luoxiaohei`.`character`.`id` =
                                                                                 `luoxiaohei`.`character-ability`.`character_id`))) left join `luoxiaohei`.`ability` on ((
        `luoxiaohei`.`character-ability`.`ability_id` = `luoxiaohei`.`ability`.`id`)))
         join `luoxiaohei`.`racial` on ((`luoxiaohei`.`character`.`racial` = `luoxiaohei`.`racial`.`id`)))
group by `luoxiaohei`.`character`.`id`;

